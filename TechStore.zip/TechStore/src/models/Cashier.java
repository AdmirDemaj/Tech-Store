package models;

import java.io.Serializable;
import java.time.LocalDate;

public class Cashier extends User implements Serializable {

    public Cashier(String username, String password, String name, LocalDate birthday, String phone, String email, int salary) {
        super(username, password, name, birthday, phone, email, salary);
    }
}
