package models;

import java.io.Serializable;
import java.time.LocalDate;

public class Admin extends User implements Serializable {
    public Admin(String username, String password){
        super(username, password, null, null, null, null, 0);
    }
    public Admin(String username, String password, String name, LocalDate birthday, String phone, String email, int salary) {
        super(username, password, name, birthday, phone, email, salary);
    }
}
