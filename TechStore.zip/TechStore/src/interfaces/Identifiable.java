package interfaces;

public interface Identifiable {
    public int getId();
}
