package util;

import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;

public class BlueButton extends Button {
    public BlueButton(String string) {
        super(string);
        this.getStylesheets().add("styles.css");
        this.getStyleClass().add("custom-button");
        this.setContentDisplay(ContentDisplay.TOP);
    }

    public BlueButton(String string, int width, int height, int font) {
        super(string);
        this.getStylesheets().add("styles.css");
        this.getStyleClass().add("custom-button");
        this.setPrefSize((double)width, (double)height);
        this.setFont(new Font(font));
        this.setTextAlignment(TextAlignment.CENTER);
        this.setContentDisplay(ContentDisplay.TOP);
    }
}
