package util;

import data.BillIO;
import data.ProductIO;
import data.UserIO;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.converter.DoubleStringConverter;
import javafx.util.converter.IntegerStringConverter;
import models.*;

import java.time.LocalDate;
import java.util.ArrayList;

public class Shared {
    public static void viewBillTable(final User usr) {
        Stage billTableStage = new Stage();
        VBox layout = new VBox();
        BillIO bio = new BillIO();
        ProductIO pio = new ProductIO();
        billTableStage.initModality(Modality.APPLICATION_MODAL);

        HBox buttons = new HBox();
        buttons.setPadding(new Insets(10, 10, 10, 10));
        buttons.setSpacing(10);

        BlueButton addBillButton = new BlueButton("Add new bill");
        buttons.getChildren().addAll(addBillButton);

        BlueButton deleteBillButton = new BlueButton("Delete selected");
        buttons.getChildren().addAll(deleteBillButton);

        BlueButton printBillButton = new BlueButton("Print selected");
        buttons.getChildren().addAll(printBillButton);

        TableColumn<Bill, LocalDate> dateColumn = new TableColumn<>("Date");
        dateColumn.setMinWidth(200);
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("date"));

        TableColumn<Bill, Float> totalColumn = new TableColumn<>("Total");
        totalColumn.setMinWidth(200);
        totalColumn.setCellValueFactory(new PropertyValueFactory<>("total"));

        TableColumn<Bill, LocalDate> ownerColumn = new TableColumn<>("Owner");
        ownerColumn.setMinWidth(200);
        ownerColumn.setCellValueFactory(new PropertyValueFactory<>("owner"));

        TableView<Bill> table = new TableView<>();
        table.setItems(getAllBills(bio));

        table.getColumns().addAll(dateColumn, totalColumn, ownerColumn);

        deleteBillButton.setOnAction(e -> {
            ArrayList<Bill> toRemove = new ArrayList<Bill>(table.getSelectionModel().getSelectedItems());
            for(Bill b : toRemove){
                bio.removeBill(b);
            }
            table.setItems(getAllBills(bio));
        });

        addBillButton.setOnAction(e -> {
            ArrayList<Product> products = viewAddBillTable();
            double total = 0;
            for(Product p : products){
                total += p.getPrice() * p.getQuantity();
            }
            if(products.size() > 0) bio.addBill(new Bill(products, total, LocalDate.now(), usr));
            table.setItems(getAllBills(bio));
        });

        printBillButton.setOnAction(e -> {
            ArrayList<Bill> toPrint = new ArrayList<Bill>(table.getSelectionModel().getSelectedItems());
            for(Bill b : toPrint){
                bio.printBill(b);
            }
        });

        layout.getChildren().addAll(buttons, table);
        Scene scene = new Scene(layout);

        billTableStage.setScene(scene);
        billTableStage.setTitle("Bills");
        billTableStage.show();
    }

    public static ObservableList<Bill> getAllBills(BillIO bio) {
        ObservableList<Bill> bills = FXCollections.observableArrayList();
        bills.addAll(bio.getBills());
        return bills;
    }

    private static ArrayList<Product> viewAddBillTable() {
        Stage billAddTableStage = new Stage();
        billAddTableStage.initModality(Modality.APPLICATION_MODAL);
        VBox layout = new VBox();
        layout.setSpacing(5);
        ProductIO pio = new ProductIO();

        TableColumn<Product, String> nameColumn = new TableColumn<>("Name");
        nameColumn.setMinWidth(200);
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));

        TableColumn<Product, Integer> quantityColumn = new TableColumn<>("Quantity");
        quantityColumn.setMinWidth(200);
        quantityColumn.setCellValueFactory(new PropertyValueFactory<>("quantity"));

        TableView<Product> table = new TableView<>();
        table.getColumns().addAll(nameColumn, quantityColumn);

        HBox inputs = new HBox();

        TextField nameInput = new TextField();
        nameInput.setPromptText("Name");
        nameInput.setMaxWidth(100);

        TextField quantityInput = new TextField();
        quantityInput.setPromptText("Quantity");
        quantityInput.setMaxWidth(100);

        inputs.getChildren().addAll(nameInput, quantityInput);
        inputs.setPadding(new Insets(10));
        inputs.setSpacing(10);
        inputs.setAlignment(Pos.CENTER);

        VBox buttons = new VBox();

        BlueButton addProductButton = new BlueButton("Add product");

        BlueButton createBillButton = new BlueButton("Create bill");
        createBillButton.setStyle("-fx-font-size: 15pt;");

        buttons.setPadding(new Insets(10));
        buttons.setAlignment(Pos.CENTER);
        buttons.getChildren().addAll(addProductButton, createBillButton);
        buttons.setSpacing(10);

        ObservableList<Product> products = FXCollections.observableArrayList();

        addProductButton.setOnAction(e -> {
            String productName = nameInput.getText();

            int productQty = 0;
            try {
                productQty = Integer.parseInt(quantityInput.getText());
            } catch (Exception ex) {
                Alert a = new Alert(Alert.AlertType.ERROR, "Invalid quantity", ButtonType.OK);
                a.show();
                return;
            }
            if (productQty <= 0) {
                Alert a = new Alert(Alert.AlertType.ERROR, "Invalid quantity", ButtonType.OK);
                a.show();
            } else {
                for (Product p : pio.getProducts()) {
                    if (p.getName().equals(productName)) {
                        if (p.getQuantity() <= 0) {
                            Alert a = new Alert(Alert.AlertType.ERROR, "Product not in stock", ButtonType.OK);
                            a.show();
                            return;
                        } else if (p.getQuantity() - productQty < 0) {
                            Alert a = new Alert(Alert.AlertType.ERROR, "There are only " + p.getQuantity() + " products left of that category", ButtonType.OK);
                            a.show();
                            return;
                        } else {
                            products.add(new Product(productName, p.getSupplier(), productQty, p.getPrice()));
                            p.setQuantity(p.getQuantity() - productQty);
                            pio.update();
                            table.setItems(products);
                            return;
                        }
                    }
                }
                Alert a = new Alert(Alert.AlertType.ERROR, "Product name not found", ButtonType.OK);
                a.show();
            }
        });

        createBillButton.setOnAction(e -> {
            if(table.getItems().size() <= 0){
                Alert a = new Alert(Alert.AlertType.ERROR, "The bill can't have 0 products", ButtonType.OK);
                a.show();
            }else{
                billAddTableStage.close();
            }
        });

        billAddTableStage.setOnCloseRequest(event -> {
            for(Product p : new ArrayList<Product>(table.getItems())){
                for(Product p2 : pio.getProducts()){
                    if(p.getName().equals(p2.getName())){
                        p2.setQuantity(p2.getQuantity() + p.getQuantity());
                        break;
                    }
                }
            }
            pio.update();
            products.clear();
        });

        layout.getChildren().addAll(table, inputs, buttons);
        Scene scene = new Scene(layout);

        billAddTableStage.setScene(scene);
        billAddTableStage.setTitle("Add Bill");
        billAddTableStage.showAndWait();

        return new ArrayList<>(table.getItems());
    }

    public static void viewProductsTable(final User usr){
        Stage productsTableStage = new Stage();
        productsTableStage.initModality(Modality.APPLICATION_MODAL);
        VBox layout = new VBox();
        ProductIO pio = new ProductIO();

        HBox buttons = new HBox();
        buttons.setPadding(new Insets(10, 10, 10, 10));
        buttons.setSpacing(10);

        BlueButton deleteBillButton = new BlueButton("Delete selected");
        buttons.getChildren().addAll(deleteBillButton);
        Label info = new Label("Double click to edit product information");
        info.setPadding(new Insets(10, 0, 0 , 0));
        buttons.getChildren().add(info);

        TableColumn<Product, String> nameColumn = new TableColumn<>("Name");
        nameColumn.setMinWidth(200);
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));

        TableColumn<Product, String> supplierColumn = new TableColumn<>("Supplier");
        supplierColumn.setMinWidth(200);
        supplierColumn.setCellValueFactory(new PropertyValueFactory<>("supplier"));

        TableColumn<Product, Integer> quantityColumn = new TableColumn<>("Stock");
        quantityColumn.setMinWidth(200);
        quantityColumn.setCellValueFactory(new PropertyValueFactory<>("quantity"));

        TableColumn<Product, Double> priceColumn = new TableColumn<>("Price");
        priceColumn.setMinWidth(200);
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        TableView<Product> table = new TableView<>();
        table.getColumns().addAll(nameColumn, supplierColumn, quantityColumn, priceColumn);
        table.setItems(getAllProducts(pio));

        table.setEditable(true);
        nameColumn.setCellFactory(TextFieldTableCell.forTableColumn());
        nameColumn.setOnEditCommit(t -> {
            t.getRowValue().setName(t.getNewValue());
            pio.update();
        });

        supplierColumn.setCellFactory(TextFieldTableCell.forTableColumn());
        supplierColumn.setOnEditCommit(t -> {
            t.getRowValue().setSupplier(t.getNewValue());
            pio.update();
        });

        quantityColumn.setCellFactory(TextFieldTableCell.forTableColumn(new IntegerStringConverter()));
        quantityColumn.setOnEditCommit(t -> {
            t.getRowValue().setQuantity(t.getNewValue());
            pio.update();
        });

        priceColumn.setCellFactory(TextFieldTableCell.forTableColumn(new DoubleStringConverter()));
        priceColumn.setOnEditCommit(t -> {
            t.getRowValue().setPrice(t.getNewValue());
            pio.update();
        });

        deleteBillButton.setOnAction(e -> {
            ArrayList<Product> toRemove = new ArrayList<Product>(table.getSelectionModel().getSelectedItems());
            for(Product p : toRemove){
                pio.removeProduct(p);
            }
            table.setItems(getAllProducts(pio));
        });

        if(usr instanceof Manager || usr instanceof Admin){
            layout.getChildren().addAll(buttons);
        }

        layout.getChildren().addAll(table);
        Scene scene = new Scene(layout);

        productsTableStage.setScene(scene);
        productsTableStage.setTitle("Available Products");
        productsTableStage.show();
    }

    private static ObservableList<Product> getAllProducts(ProductIO pio) {
        ObservableList<Product> products = FXCollections.observableArrayList();
        products.addAll(pio.getProducts());
        return products;
    }

    public static void viewAddProduct(){
        Stage addProductStage = new Stage();
        addProductStage.initModality(Modality.APPLICATION_MODAL);
        VBox layout = new VBox();
        layout.setPadding(new Insets(10));
        layout.setSpacing(10);
        layout.setAlignment(Pos.CENTER);
        ProductIO pio = new ProductIO();

        HBox inputs1 = new HBox();
        inputs1.setSpacing(5);

        TextField nameInput = new TextField();
        nameInput.setPromptText("Name");
        inputs1.getChildren().add(nameInput);

        TextField supplierInput = new TextField();
        supplierInput.setPromptText("Supplier");
        inputs1.getChildren().add(supplierInput);

        HBox inputs2 = new HBox();
        inputs2.setSpacing(5);

        TextField quantityInput = new TextField();
        quantityInput.setPromptText("Quantity");
        inputs2.getChildren().add(quantityInput);

        TextField priceInput = new TextField();
        priceInput.setPromptText("Price");
        inputs2.getChildren().add(priceInput);

        BlueButton addProductButton = new BlueButton("Add Product");

        addProductButton.setOnAction(e -> {
            for(Product p : pio.getProducts()){
                if(p.getName().equals(nameInput.getText())){
                    Alert a = new Alert(Alert.AlertType.ERROR, "Product with that name already exists", ButtonType.OK);
                    a.show();
                    return;
                }
            }
            if(nameInput.getText().equals("")){
                Alert a = new Alert(Alert.AlertType.ERROR, "Your product must have a name", ButtonType.OK);
                a.show();
            } else {
                int productQty;
                try {
                    productQty = Integer.parseInt(quantityInput.getText());
                }catch (Exception ex){
                    Alert a = new Alert(Alert.AlertType.ERROR, "Invalid quantity", ButtonType.OK);
                    a.show();
                    ex.getStackTrace();
                    return;
                }
                double productPrice;
                try {
                    productPrice = Double.parseDouble(priceInput.getText());
                }catch (Exception ex){
                    Alert a = new Alert(Alert.AlertType.ERROR, "Invalid price", ButtonType.OK);
                    a.show();
                    ex.getStackTrace();
                    return;
                }
                Product newProduct = new Product(nameInput.getText(), supplierInput.getText(), productQty, productPrice);
                pio.addProduct(newProduct);
                Alert a = new Alert(Alert.AlertType.INFORMATION, "Product added", ButtonType.OK);
                a.show();
                addProductStage.close();
            }
        });

        layout.getChildren().addAll(inputs1, inputs2, addProductButton);
        Scene scene = new Scene(layout);

        addProductStage.setScene(scene);
        addProductStage.setTitle("Add new product");
        addProductStage.showAndWait();
    }

    public static void viewAddStock(){
        Stage addStockStage = new Stage();
        addStockStage.initModality(Modality.APPLICATION_MODAL);
        VBox layout = new VBox();
        layout.setPadding(new Insets(10));
        layout.setSpacing(10);
        layout.setAlignment(Pos.CENTER);
        layout.setMinWidth(300);
        ProductIO pio = new ProductIO();

        TextField inputName = new TextField();
        inputName.setPromptText("Product name");

        TextField inputQuantity = new TextField();
        inputQuantity.setPromptText("Quantity to add");

        BlueButton stockUpButton = new BlueButton("Stock up");

        stockUpButton.setOnAction(e -> {
            for(Product p : pio.getProducts()){
                if(p.getName().equals(inputName.getText())){

                    int qty = 0;
                    try{
                        qty = Integer.parseInt(inputQuantity.getText());
                    }catch (Exception ex){
                        Alert a = new Alert(Alert.AlertType.ERROR, "Invalid quantity", ButtonType.OK);
                        a.show();
                        ex.getStackTrace();
                        return;
                    }

                    if(qty <= 0){
                        Alert a = new Alert(Alert.AlertType.ERROR, "Invalid quantity", ButtonType.OK);
                        a.show();
                    }else{
                        p.setQuantity(p.getQuantity() + qty);
                        pio.update();
                        Alert a = new Alert(Alert.AlertType.INFORMATION, "Product stock updated", ButtonType.OK);
                        a.show();
                        addStockStage.close();
                        return;
                    }
                }
            }
            Alert a = new Alert(Alert.AlertType.ERROR, "Product with that name not found", ButtonType.OK);
            a.show();
        });

        layout.getChildren().addAll(inputName, inputQuantity, stockUpButton);
        Scene scene = new Scene(layout);

        addStockStage.setScene(scene);
        addStockStage.setTitle("Add stock");
        addStockStage.showAndWait();
    }

    public static void viewCashierStats(){
        Stage viewCashierStatsStage = new Stage();
        viewCashierStatsStage.initModality(Modality.APPLICATION_MODAL);
        VBox layout = new VBox();
        layout.setPadding(new Insets(10));
        layout.setSpacing(10);
        layout.setAlignment(Pos.CENTER);
        layout.setMinWidth(300);
        BillIO bio = new BillIO();
        UserIO uio = new UserIO();

        HBox dates = new HBox();
        dates.setPadding(new Insets(10));
        dates.setSpacing(10);
        DatePicker startDate = new DatePicker();
        startDate.setMaxWidth(200);
        startDate.setPromptText("Start date");
        DatePicker endDate = new DatePicker();
        endDate.setPromptText("End date");
        endDate.setMaxWidth(200);
        BlueButton updateButton = new BlueButton("Update");
        BlueButton clearButton = new BlueButton("Clear Dates");
        dates.getChildren().addAll(startDate, endDate, updateButton, clearButton);

        TableColumn<Cashier, String> nameColumn = new TableColumn<>("Cashier");
        nameColumn.setMinWidth(200);
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));

        TableColumn<Cashier, Integer> billCountColumn = new TableColumn<>("Bill Count");
        billCountColumn.setMinWidth(200);
        billCountColumn.setCellValueFactory(tf -> {
            int count = 0;
            LocalDate start = startDate.getValue();
            LocalDate end = endDate.getValue();
            if(start != null && end != null) {
                for (Bill b : bio.getBills()) {
                    if (b.getOwner().getId() == tf.getValue().getId()) {
                        if (b.getDate().compareTo(start) >= 0 && b.getDate().compareTo(end) <= 0) {
                            count++;
                        }
                    }
                }
            }
            else if(start != null){
                for (Bill b : bio.getBills()) {
                    if (b.getOwner().getId() == tf.getValue().getId()) {
                        if (b.getDate().compareTo(start) >= 0) {
                            count++;
                        }
                    }
                }
            }else if(end != null){
                for (Bill b : bio.getBills()) {
                    if (b.getOwner().getId() == tf.getValue().getId()) {
                        if (b.getDate().compareTo(end) <= 0) {
                            count++;
                        }
                    }
                }
            }else{
                for(Bill b : bio.getBills()){
                    if(b.getOwner().getId() == tf.getValue().getId()){
                            count++;
                    }
                }
            }
            return new ReadOnlyObjectWrapper<>(count);
        });

        TableColumn<Cashier, Double> totalAmountColumn = new TableColumn<>("Total Amount");
        totalAmountColumn.setMinWidth(200);
        totalAmountColumn.setCellValueFactory(tf -> {
            double totalAmount = 0;
            LocalDate start = startDate.getValue();
            LocalDate end = endDate.getValue();
            if(start != null && end != null) {
                for (Bill b : bio.getBills()) {
                    if (b.getOwner().getId() == tf.getValue().getId()) {
                        if (b.getDate().compareTo(start) >= 0 && b.getDate().compareTo(end) <= 0) {
                            totalAmount += b.getTotal();
                        }
                    }
                }
            }else if(start != null){
                for (Bill b : bio.getBills()) {
                    if (b.getOwner().getId() == tf.getValue().getId()) {
                        if (b.getDate().compareTo(start) >= 0) {
                            totalAmount += b.getTotal();
                        }
                    }
                }
            }else if(end != null){
                for (Bill b : bio.getBills()) {
                    if (b.getOwner().getId() == tf.getValue().getId()) {
                        if (b.getDate().compareTo(end) <= 0) {
                            totalAmount += b.getTotal();
                        }
                    }
                }
            }else{
                for (Bill b : bio.getBills()) {
                    if (b.getOwner().getId() == tf.getValue().getId()) {

                        totalAmount += b.getTotal();
                    }
                }
            }
            return new ReadOnlyObjectWrapper<>(totalAmount);
        });

        TableView<Cashier> table = new TableView<>();
        table.getColumns().addAll(nameColumn, billCountColumn, totalAmountColumn);

        for(User u : uio.getUsers()){
            if(u instanceof Cashier){
                table.getItems().add((Cashier) u);
            }
        }

        updateButton.setOnAction(e -> {
            table.getColumns().get(1).setVisible(false);
            table.getColumns().get(1).setVisible(true);
            table.getColumns().get(2).setVisible(false);
            table.getColumns().get(2).setVisible(true);
        });

        clearButton.setOnAction(e -> {
            startDate.getEditor().clear();
            endDate.getEditor().clear();
            startDate.setValue(null);
            endDate.setValue(null);
            table.getColumns().get(1).setVisible(false);
            table.getColumns().get(1).setVisible(true);
            table.getColumns().get(2).setVisible(false);
            table.getColumns().get(2).setVisible(true);
        });


        layout.getChildren().addAll(dates, table);
        Scene scene = new Scene(layout);

        viewCashierStatsStage.setScene(scene);
        viewCashierStatsStage.setTitle("Cashier Stats");
        viewCashierStatsStage.showAndWait();
    }

}
