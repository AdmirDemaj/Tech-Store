package application;

import data.UserIO;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import models.User;
import util.BlueButton;
import util.Shared;

public class CashierStage {
    public void view(User usr, final UserIO uio) {
        Stage cashierStage = new Stage();
        cashierStage.setResizable(false);
        HBox layout = new HBox();
        layout.setPadding(new Insets(20));
        layout.setSpacing(20);
        layout.setAlignment(Pos.CENTER);

        BlueButton viewBillsButton = new BlueButton("Bills", 150, 150, 22);
        BlueButton viewProductsButton = new BlueButton("View\nProducts", 150, 150, 22);

        layout.getChildren().addAll(viewBillsButton, viewProductsButton);
        Scene scene = new Scene(layout);

        cashierStage.setScene(scene);
        cashierStage.setTitle("Cashier Panel");
        cashierStage.show();

        viewBillsButton.setOnAction(e -> {
            Shared.viewBillTable(usr);
        });

        viewProductsButton.setOnAction(e -> {
            Shared.viewProductsTable(usr);
        });

    }
}
