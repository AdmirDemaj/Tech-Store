package application;

import javafx.application.Application;
import javafx.stage.Stage;

public class Main extends Application {
    public Main() {
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        LoginStage login = new LoginStage();
        login.view();
    }

    public static void main(String[] args) { launch(args); }
}
