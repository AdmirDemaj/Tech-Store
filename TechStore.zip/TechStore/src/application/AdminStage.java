package application;

import data.BillIO;
import data.ProductIO;
import data.UserIO;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.converter.IntegerStringConverter;
import models.*;
import util.BlueButton;
import util.Shared;

import java.time.LocalDate;
import java.util.ArrayList;

public class AdminStage {
    public void view(User usr, final UserIO uio) {
        Stage managerStage = new Stage();
        managerStage.setResizable(false);

        VBox layout = new VBox();

        HBox b1 = new HBox();
        b1.setPadding(new Insets(20));
        b1.setSpacing(20);
        b1.setAlignment(Pos.CENTER);

        HBox b2 = new HBox();
        b2.setPadding(new Insets(20));
        b2.setSpacing(20);
        b2.setAlignment(Pos.CENTER);

        BlueButton viewBillsButton = new BlueButton("Bills", 150, 150, 22);
        BlueButton viewProductsButton = new BlueButton("Products", 150, 150, 22);
        BlueButton viewAddProductsButton = new BlueButton("Add\nProduct", 150, 150, 22);
        BlueButton viewAddStockButton = new BlueButton("Add\nStock", 150, 150, 22);
        BlueButton viewCashierStatsButton = new BlueButton("Cashier\nStats", 150, 150, 22);
        BlueButton viewEmployeesButton = new BlueButton("Employees", 150, 150, 22);
        BlueButton viewAddEmployeeButton = new BlueButton("Add\nEmployee", 150, 150, 22);
        BlueButton viewStatsButton = new BlueButton("Store\nStats", 150, 150, 22);

        b1.getChildren().addAll(viewBillsButton, viewProductsButton, viewAddProductsButton, viewAddStockButton);
        b2.getChildren().addAll(viewCashierStatsButton, viewEmployeesButton, viewAddEmployeeButton, viewStatsButton);

        layout.getChildren().addAll(b1, b2);

        Scene scene = new Scene(layout);

        managerStage.setScene(scene);
        managerStage.setTitle("Administrator Panel");
        managerStage.show();

        viewBillsButton.setOnAction(e -> {
            Shared.viewBillTable(usr);
        });

        viewProductsButton.setOnAction(e -> {
            Shared.viewProductsTable(usr);
        });

        viewAddProductsButton.setOnAction(e -> {
            Shared.viewAddProduct();
        });

        viewAddStockButton.setOnAction(e -> {
            Shared.viewAddStock();
        });

        viewCashierStatsButton.setOnAction(e -> {
            Shared.viewCashierStats();
        });

        viewEmployeesButton.setOnAction(e -> {
            Stage employeeTableStage = new Stage();
            VBox layout2 = new VBox();
            employeeTableStage.initModality(Modality.APPLICATION_MODAL);

            HBox buttons = new HBox();
            buttons.setPadding(new Insets(10, 10, 10, 10));
            buttons.setSpacing(10);

            BlueButton deleteBillButton = new BlueButton("Delete selected");
            Label info = new Label("Double click to edit employee information");
            info.setPadding(new Insets(10, 0, 0 , 0));
            buttons.getChildren().addAll(deleteBillButton, info);

            TableColumn<User, String> nameColumn = new TableColumn<>("Name");
            nameColumn.setMinWidth(200);
            nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));

            TableColumn<User, String> usernameColumn = new TableColumn<>("Username");
            usernameColumn.setMinWidth(200);
            usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));

            TableColumn<User, String> birthdayColumn = new TableColumn<>("Birthday");
            birthdayColumn.setMinWidth(200);
            birthdayColumn.setCellValueFactory(new PropertyValueFactory<>("birthday"));

            TableColumn<User, String> phoneColumn = new TableColumn<>("Phone");
            phoneColumn.setMinWidth(200);
            phoneColumn.setCellValueFactory(new PropertyValueFactory<>("phone"));

            TableColumn<User, String> emailColumn = new TableColumn<>("Email");
            emailColumn.setMinWidth(200);
            emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));

            TableColumn<User, Integer> salaryColumn = new TableColumn<>("Salary");
            salaryColumn.setMinWidth(200);
            salaryColumn.setCellValueFactory(new PropertyValueFactory<>("salary"));

            TableColumn<User, String> roleColumn = new TableColumn<>("Role");
            roleColumn.setMinWidth(200);
            roleColumn.setCellValueFactory(t -> {
                String role = t.getValue().getClass().getSimpleName();
                return new ReadOnlyObjectWrapper<>(role);
            });

            TableView<User> table = new TableView<>();
            ObservableList<User> employees = FXCollections.observableArrayList();
            employees.addAll(uio.getUsers());
            table.setItems(employees);

            table.getColumns().addAll(nameColumn, usernameColumn, birthdayColumn, phoneColumn, emailColumn, salaryColumn, roleColumn);

            table.setEditable(true);
            nameColumn.setCellFactory(TextFieldTableCell.forTableColumn());
            nameColumn.setOnEditCommit(t -> {
                t.getRowValue().setName(t.getNewValue());
                uio.update();
            });

            usernameColumn.setCellFactory(TextFieldTableCell.forTableColumn());
            usernameColumn.setOnEditCommit(t -> {
                t.getRowValue().setUsername(t.getNewValue());
                uio.update();
            });

            phoneColumn.setCellFactory(TextFieldTableCell.forTableColumn());
            phoneColumn.setOnEditCommit(t -> {
                t.getRowValue().setPhone(t.getNewValue());
                uio.update();
            });

            emailColumn.setCellFactory(TextFieldTableCell.forTableColumn());
            emailColumn.setOnEditCommit(t -> {
                t.getRowValue().setEmail(t.getNewValue());
                uio.update();
            });

            salaryColumn.setCellFactory(TextFieldTableCell.forTableColumn(new IntegerStringConverter()));
            salaryColumn.setOnEditCommit(t -> {
                t.getRowValue().setSalary(t.getNewValue());
                uio.update();
            });

            deleteBillButton.setOnAction(e2 -> {
                ArrayList<User> toRemove = new ArrayList<User>(table.getSelectionModel().getSelectedItems());
                for(User u : toRemove){
                    uio.removeUser(u);
                }
                employees.clear();
                employees.addAll(uio.getUsers());
                table.setItems(employees);
            });

            layout2.getChildren().addAll(buttons, table);
            Scene scene2 = new Scene(layout2);
            employeeTableStage.setScene(scene2);
            employeeTableStage.setTitle("Employee Information");
            employeeTableStage.show();
        });

        viewAddEmployeeButton.setOnAction(e -> {
            Stage addEmployeeStage = new Stage();
            VBox layout3 = new VBox();
            layout3.setMinWidth(400);
            layout3.setPadding(new Insets(20));
            layout3.setSpacing(10);
            addEmployeeStage.initModality(Modality.APPLICATION_MODAL);

            TextField usernameInput = new TextField();
            usernameInput.setPromptText("Username");
            PasswordField passwordInput = new PasswordField();
            passwordInput.setPromptText("Password");
            TextField nameInput = new TextField();
            nameInput.setPromptText("Name");
            DatePicker birthdayInput = new DatePicker();
            birthdayInput.setPromptText("Birthday");
            TextField phoneInput = new TextField();
            phoneInput.setPromptText("Phone");
            TextField emailInput = new TextField();
            emailInput.setPromptText("Email");
            TextField salaryInput = new TextField();
            salaryInput.setPromptText("Salary");
            ComboBox<String> roleInput = new ComboBox<>();
            roleInput.getItems().add("Cashier");
            roleInput.getItems().add("Manager");
            roleInput.getItems().add("Admin");

            BlueButton addUserButton = new BlueButton("Add employee");

            addUserButton.setOnAction(e2 -> {
                int salaryNum = 0;

                try{
                    salaryNum = Integer.parseInt(salaryInput.getText());
                }catch (Exception ex){
                    Alert a = new Alert(Alert.AlertType.ERROR, "Invalid salary", ButtonType.OK);
                    a.show();
                    ex.getStackTrace();
                    return;
                }

                if(usernameInput.getText().equals("")
                || passwordInput.getText().equals("")
                || nameInput.getText().equals("")){
                    Alert a = new Alert(Alert.AlertType.ERROR, "Username, password or name can't be blank", ButtonType.OK);
                    a.show();
                    return;
                }

                for(User u : uio.getUsers()){
                    if(u.getUsername().equals(usernameInput.getText())){
                        Alert a = new Alert(Alert.AlertType.ERROR, "User with that username already exists", ButtonType.OK);
                        a.show();
                        return;
                    }
                }

                String role = (String) roleInput.getValue().toString();
                switch (role) {
                    case "Cashier":
                        uio.addUser(new Cashier(usernameInput.getText(), passwordInput.getText(), nameInput.getText(), birthdayInput.getValue(), phoneInput.getText(), emailInput.getText(), salaryNum));
                        break;
                    case "Manager":
                        uio.addUser(new Manager(usernameInput.getText(), passwordInput.getText(), nameInput.getText(), birthdayInput.getValue(), phoneInput.getText(), emailInput.getText(), salaryNum));
                        break;
                    case "Admin":
                        uio.addUser(new Admin(usernameInput.getText(), passwordInput.getText(), nameInput.getText(), birthdayInput.getValue(), phoneInput.getText(), emailInput.getText(), salaryNum));
                        break;
                    default:
                        Alert a = new Alert(Alert.AlertType.ERROR, "Invalid role", ButtonType.OK);
                        a.show();
                        return;
                }
                Alert a = new Alert(Alert.AlertType.INFORMATION, "Employee added", ButtonType.OK);
                a.show();
                addEmployeeStage.close();
            });

            layout3.getChildren().addAll(usernameInput, passwordInput, nameInput, birthdayInput, phoneInput, emailInput, salaryInput, roleInput, addUserButton);
            Scene scene3 = new Scene(layout3);
            addEmployeeStage.setScene(scene3);
            addEmployeeStage.setTitle("Add Employee");
            addEmployeeStage.showAndWait();
        });

        viewStatsButton.setOnAction(e -> {
            Stage viewStatsStage = new Stage();
            viewStatsStage.initModality(Modality.APPLICATION_MODAL);
            VBox layout4 = new VBox();
            layout4.setPadding(new Insets(10));
            layout4.setSpacing(10);
            layout4.setAlignment(Pos.CENTER);
            layout4.setMinWidth(300);
            BillIO bio = new BillIO();
            ProductIO pio = new ProductIO();

            LocalDate month = LocalDate.now().withDayOfMonth(1);
            double totalMonth = 0;
            for(Bill b : bio.getBills()){
                if(b.getDate().compareTo(month) >= 0){
                    totalMonth += b.getTotal();
                }
            }
            HBox thisMonthEarnings = new HBox();
            Label l1 = new Label("This Month's Earnings: ");
            l1.setFont(new Font(20));
            Label l2 =  new Label(String.valueOf(totalMonth));
            l2.setFont(new Font(20));
            thisMonthEarnings.getChildren().addAll(l1, l2);

            LocalDate today = LocalDate.now();
            double totalToday = 0;
            for(Bill b : bio.getBills()){
                if(b.getDate().compareTo(today) == 0){
                    totalToday += b.getTotal();
                }
            }
            HBox todayEarnings = new HBox();
            Label l3 = new Label("Today's Earnings: ");
            l3.setFont(new Font(20));
            Label l4 =  new Label(String.valueOf(totalToday));
            l4.setFont(new Font(20));
            todayEarnings.getChildren().addAll(l3, l4);

            double totalStaff = 0;
            for(User u : uio.getUsers()){
                totalStaff += u.getSalary();
            }
            HBox staffSalaries = new HBox();
            Label l5 = new Label("Staff Salaries: ");
            l5.setFont(new Font(20));
            Label l6 =  new Label(String.valueOf(totalStaff));
            l6.setFont(new Font(20));
            staffSalaries.getChildren().addAll(l5, l6);

            double productsBoughtTotal = 0;
            for(Product p : pio.getProducts()){
                productsBoughtTotal += p.getQuantity() * p.getPrice();
            }
            HBox productsBought = new HBox();
            Label l7 = new Label("Products Bought Total: ");
            l7.setFont(new Font(20));
            Label l8 =  new Label(String.valueOf(productsBoughtTotal));
            l8.setFont(new Font(20));
            productsBought.getChildren().addAll(l7, l8);


            layout4.getChildren().addAll(thisMonthEarnings, todayEarnings, staffSalaries, productsBought);
            Scene scene4 = new Scene(layout4);

            viewStatsStage.setScene(scene4);
            viewStatsStage.setTitle("Stats");
            viewStatsStage.showAndWait();
        });

    }
}
