package application;

import data.UserIO;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import models.User;
import util.BlueButton;
import util.Shared;

public class ManagerStage {
    public void view(User usr, final UserIO uio) {
        Stage managerStage = new Stage();
        managerStage.setResizable(false);
        HBox layout = new HBox();
        layout.setPadding(new Insets(20));
        layout.setSpacing(20);
        layout.setAlignment(Pos.CENTER);

        BlueButton viewBillsButton = new BlueButton("Manage\nBills", 150, 150, 22);
        BlueButton viewProductsButton = new BlueButton("View\nProducts", 150, 150, 22);
        BlueButton viewAddProductsButton = new BlueButton("Add\nProduct", 150, 150, 22);
        BlueButton viewAddStockButton = new BlueButton("Add\nStock", 150, 150, 25);
        BlueButton viewCashierStatsButton = new BlueButton("View\nCashier\nStats", 150, 150, 22);

        layout.getChildren().addAll(viewBillsButton, viewProductsButton, viewAddProductsButton, viewAddStockButton, viewCashierStatsButton);
        Scene scene = new Scene(layout);

        managerStage.setScene(scene);
        managerStage.setTitle("Manager Panel");
        managerStage.show();

        viewBillsButton.setOnAction(e -> {
            Shared.viewBillTable(usr);
        });

        viewProductsButton.setOnAction(e -> {
            Shared.viewProductsTable(usr);
        });

        viewAddProductsButton.setOnAction(e -> {
            Shared.viewAddProduct();
        });

        viewAddStockButton.setOnAction(e -> {
            Shared.viewAddStock();
        });

        viewCashierStatsButton.setOnAction(e -> {
            Shared.viewCashierStats();
        });

    }
}
