package application;

import data.ProductIO;
import data.UserIO;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import models.*;
import util.BlueButton;

public class LoginStage {

    public void view() {
        Stage stage = new Stage();

        GridPane login = new GridPane();
        login.setHgap(10);
        login.setVgap(10);
        login.setPadding(new Insets(30, 30, 30, 30));

        Label title = new Label("Tech-Store Panel");
        title.setTextFill(Color.web("#4592af"));
        title.setAlignment(Pos.CENTER);
        title.setFont(new Font(40));
        login.add(title, 1, 0);

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");
        usernameField.setMinHeight(40);
        usernameField.setMaxWidth(300);
        login.add(usernameField, 1, 1);

        TextField passwordField = new PasswordField();
        passwordField.setPromptText("Password");
        passwordField.setMinHeight(40);
        passwordField.setMaxWidth(300);
        login.add(passwordField, 1, 3);

        BlueButton loginButton = new BlueButton("Login", 80, 40, 18);
        login.add(loginButton, 1, 4);

        loginButton.setOnAction(e -> {
            UserIO uio = new UserIO();
            ProductIO pio = new ProductIO();
            boolean found = false;
            for(User u : uio.getUsers()) {
                if(u.getUsername().equals(usernameField.getText()) && u.getPassword().equals(passwordField.getText())) {
                    if(u instanceof Admin){
                        AdminStage adminStage = new AdminStage();
                        adminStage.view(u, uio);
                    }else if(u instanceof Manager){
                        ManagerStage managerStage = new ManagerStage();
                        managerStage.view(u, uio);
                        for(Product p : pio.getProducts()){
                            if(p.getQuantity() < 5){
                                Alert a = new Alert(Alert.AlertType.INFORMATION, "One or more of the items in your store are less than 5 in stock", ButtonType.OK);
                                a.show();
                                break;
                            }
                        }
                    }else if(u instanceof Cashier){
                        CashierStage cashierStage = new CashierStage();
                        cashierStage.view(u, uio);
                    }
                    found = true;
                    stage.close();
                }
            }
            if(!found) {
                Alert a = new Alert(Alert.AlertType.ERROR, "User not found", ButtonType.OK);
                a.show();
            }
        });

        Scene loginScene = new Scene(login);
        stage.setScene(loginScene);
        stage.setTitle("Login");
        stage.showAndWait();
    }
}
