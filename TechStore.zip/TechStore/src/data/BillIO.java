package data;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import models.Bill;
import models.Product;

import java.io.*;
import java.util.ArrayList;

public class BillIO {
    private ArrayList<Bill> bills;
    private String path;
    private File file;

    public BillIO() {
        this.path = "files" + File.separator + "bills.bin";
        this.bills = new ArrayList<Bill>();
        this.file = new File(this.path);
        boolean created = this.file.getParentFile().mkdirs();
        if (this.file.exists()) {
            this.read();
        }
    }

    @SuppressWarnings({ "unchecked"})
    private void read() {
        try {
            FileInputStream fis = new FileInputStream(this.file);
            ObjectInputStream ois = new ObjectInputStream(fis);
            this.bills = (ArrayList<Bill>) ois.readObject();
            ois.close();
            fis.close();
        } catch (IOException | ClassNotFoundException err) {
            err.printStackTrace();
        }
    }

    private void write() {
        try {
            FileOutputStream fos = new FileOutputStream(this.file);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(this.bills);
            oos.close();
            fos.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public void update() {
        this.write();
    }

    public void removeBill(Bill bill) {
        this.bills.remove(bill);
        this.write();
    }

    public void addBill(Bill bill){
        bill.setId(this.getId());
        this.bills.add(bill);
        this.write();
    }

    private int getId() {
        int id = 0;
        if (this.bills.size() != 0) {
            id = ( (Bill) this.bills.get( this.bills.size() - 1) ).getId();
        }
        ++id;
        return id;
    }

    public ArrayList<Bill> getBills() {
        return bills;
    }

    public void printBill(Bill b) {
        try{
            File file = new File("files" + File.separator + "bills" + File.separator + b.getOwner().getName() + File.separator + b.getId() + ".txt");
            boolean created = file.getParentFile().mkdirs();
            PrintWriter pwr = new PrintWriter(file);
            pwr.println(b.getDate().toString() + "                " + b.getOwner().getName());
            pwr.println("=====================================");
            pwr.printf("%-20s%-10s%-5s\n", "Product", "Quantity", "Price");
            for(Product p : b.getProducts()){
                pwr.printf("%-20s%-10s%-5s\n", p.getName(), p.getQuantity(), p.getPrice());
            }
            pwr.println("=====================================");
            pwr.write("Total: " + b.getTotal());
            pwr.close();
            Alert al = new Alert(Alert.AlertType.INFORMATION, "Bill printed successfully", ButtonType.OK);
            al.show();
        } catch (FileNotFoundException e) {
            Alert al = new Alert(Alert.AlertType.ERROR, "Error in printing bill", ButtonType.OK);
            al.show();
            e.printStackTrace();
        }
    }

}
