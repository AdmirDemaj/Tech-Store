package data;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import models.Admin;
import models.Cashier;
import models.Manager;
import models.User;

import java.io.*;
import java.util.ArrayList;

public class UserIO {
    private ArrayList<User> users;
    private String path;
    private File file;

    public UserIO() {
        this.path = "files" + File.separator + "users.bin";
        this.file = new File(path);
        this.users = new ArrayList<User>();
        boolean created = file.getParentFile().mkdirs();
        if (file.exists()) {
            this.read();
        }
    }

    @SuppressWarnings({ "unchecked"})
    private void read() {
        try {
            FileInputStream fis = new FileInputStream(this.file);
            ObjectInputStream ois = new ObjectInputStream(fis);
            this.users = (ArrayList<User>) ois.readObject();
            ois.close();
            fis.close();
        } catch (ClassNotFoundException | IOException ex) {
            ex.printStackTrace();
        }
    }

    private void write() {
        try {
            FileOutputStream fos = new FileOutputStream(this.file);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(this.users);
            oos.close();
            fos.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public void update() {
        this.write();
    }

    public void addUser(User user){
        user.setId(this.getId());
        this.users.add(user);
        this.write();
    }

    public void removeUser(User user) {
        this.users.remove(user);
        this.write();
    }

    private int getId() {
        int id = 0;
        if (this.users.size() != 0) {
            id = ( (User) this.users.get( this.users.size() - 1) ).getId();
        }
        ++id;
        return id;
    }

    public ArrayList<User> getUsers() {
        return users;
    }


}
