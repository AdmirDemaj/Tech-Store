package data;

import models.Product;

import java.io.*;
import java.util.ArrayList;

public class ProductIO {
    private ArrayList<Product> products;
    private String path;
    private File file;

    public ProductIO() {
        this.path = "files" + File.separator + "products.bin";
        this.products = new ArrayList<Product>();
        this.file = new File(this.path);
        boolean created = this.file.getParentFile().mkdirs();
        if (this.file.exists()) {
            this.read();
        }
    }

    @SuppressWarnings({ "unchecked"})
    private void read() {
        try {
            FileInputStream fis = new FileInputStream(this.file);
            ObjectInputStream ois = new ObjectInputStream(fis);
            this.products = (ArrayList<Product>) ois.readObject();
            ois.close();
            fis.close();
        } catch (IOException | ClassNotFoundException err) {
            err.printStackTrace();
        }
    }

    private void write() {
        try {
            FileOutputStream fos = new FileOutputStream(this.file);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(this.products);
            oos.close();
            fos.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public void update() {
        this.write();
    }

    public void removeProduct(Product product) {
        this.products.remove(product);
        this.write();
    }

    public void addProduct(Product product){
        this.products.add(product);
        this.write();
    }

    public ArrayList<Product> getProducts() {
        return products;
    }

}
